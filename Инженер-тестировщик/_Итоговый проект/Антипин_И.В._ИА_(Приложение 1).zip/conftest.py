import pytest
from utils.api_client import API_BASE_URL as api_client

@pytest.fixture()   #scope='function'
def api_base_url():

    """
    Возвращает базовый адрес API
    используется в модулях test_* """

    return  api_client.API_BASE_URL






