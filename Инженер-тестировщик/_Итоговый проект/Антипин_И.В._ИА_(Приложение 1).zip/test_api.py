from importlib.metadata.diagnose import inspect

import allure
#import requests
import json
from requests import Response

#from requests import Request

#import utils.faker_data as faker_data
import utils.api_client as api_client
import utils.client_util as client_util
import utils.faker_data as faker_data
import inspect


class TestUserAPI:

  api_client_user = api_client.APIClientUser()  #объект APIClientUser() для вызова методов класса APIClientUser()
  data_http = {"data_request": {},
               "data_response": Response}

  def test_create_user(self):
      client_util_obj = client_util.ClientUtil()
      current_step = 1
      print("\n\r")
      frame = inspect.currentframe()
      print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
# Сначала Создание нового пользователя с вымышленными данными
      if client_util_obj.exec_create_user():
# Если создание успешно, получим данные этого пользователя и сравним результат с тем, что было записано
#       if client_util_obj.exec_get_user(client_util_obj.user_name_current, ""):
         print(f'Пользователь: {client_util_obj.user_name_current} создан успешно')
      return

  def test_get_user(self):

      client_util_obj = client_util.ClientUtil()
      current_step = 1
      print("\n\r")
      frame = inspect.currentframe()
      print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
      # Сначала создадим нового пользователя
      # Создание нового пользователя с вымышленными данными
      if client_util_obj.exec_create_user():
          # Если создание успешно, получим данные этого пользователя и сравним результат с тем, что было записано
          current_step += 1
          print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
          if client_util_obj.exec_get_user(client_util_obj.user_name_current, ""):
              print(f'Данные пользователя: {client_util_obj.user_name_current} получены успешно')
      return

  def test_create_update(self):

      client_util_obj = client_util.ClientUtil()
      current_step = 1
      print("\n\r")
      frame = inspect.currentframe()
      print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
      # Сначала Создание нового пользователя с вымышленными данными
      if client_util_obj.exec_create_user():
        # Если создание успешно, выполним вход этим пользователем
        current_step += 1
        print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
        if client_util_obj.exec_login_user(client_util_obj.user_name_current, client_util_obj.user_password_current):
           print(f'Пользователь: {client_util_obj.user_name_current} произвёл вход успешно')

        # Замена электронной почты и телефона согласно условия
           tmp_user_data = client_util_obj.data_http["data_response"].json()
           tmp_user_data["email"] = "1234@6543.org"
           tmp_user_data["phone"] = "+732764938248924"
           current_step += 1
           print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
           if client_util_obj.exec_update_user(client_util_obj.user_name_current):
             print(f'Данные пользователя: {client_util_obj.user_name_current} обновлены успешно')
           else:
             print(f'Данные пользователя: {client_util_obj.user_name_current} не обновлены в связи с ошибкой')

      return

  def test_user_login_success(self):
    client_util_obj = client_util.ClientUtil()
    current_step = 1
    print("\n\r")
    frame = inspect.currentframe()
    print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
    # Сначала создадим нового пользователя
    # Создание нового пользователя с вымышленными данными
    if client_util_obj.exec_create_user(faker_data.FakerUserData('en_ENG').generate_user_test_data()):
        # Если создание успешно, то проверяем вход под этим пользователем
        current_step += 1
        print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
        if client_util_obj.exec_login_user(client_util_obj.user_name_current, client_util_obj.user_password_current):
            print(f'Пользователь: {client_util_obj.user_name_current} произвёл вход успешно')
    return

  def test_user_logout(self):
    client_util_obj = client_util.ClientUtil()
    current_step = 1
    print("\n\r")
    frame = inspect.currentframe()
    print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
    # Сначала создадим нового пользователя
    # Создание нового пользователя с вымышленными данными
    if client_util_obj.exec_create_user(faker_data.FakerUserData('en_ENG').generate_user_data()):
        # Если создание успешно, то проверяем вход под этим пользователем
        current_step += 1
        print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
        if client_util_obj.exec_login_user(client_util_obj.user_name_current, client_util_obj.user_password_current):
           print(f'Пользователь: {client_util_obj.user_name_current} произвёл вход успешно')
        # Если вход был успешным, то производим выход
           current_step += 1
           print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
           if client_util_obj.exec_logout_user():
              print(f'Пользователь: {client_util_obj.user_name_current} произвёл выход успешно')

    return

  def test_create_user_with_locale(self):

      client_util_obj = client_util.ClientUtil()
      current_step = 1
      print("\n\r")
      frame = inspect.currentframe()
      # Сначала Создание нового пользователя с вымышленными данными
      if client_util_obj.exec_create_user(faker_data.FakerUserData('ru_RUS').generate_user_user1_data()):
          # Если создание успешно, получим данные этого пользователя и сравним результат с тем, что было записано
          current_step += 1
          print(f'тест: {frame.f_code.co_name}; шаг: {current_step}')
          if client_util_obj.exec_get_user(client_util_obj.user_name_current, client_util_obj.user_name_current):
              print(f'Пользователь: {client_util_obj.user_name_current} создан успешно')
      return
