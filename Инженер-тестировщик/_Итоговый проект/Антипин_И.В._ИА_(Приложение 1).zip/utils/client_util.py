import allure
#import requests
import json
from colorama import init, Fore, Back, Style
from requests import Response

import utils.api_client as api_client
import utils.faker_data as faker_data



class ClientUtil:

  api_client_user = api_client.APIClientUser()  #объект APIClientUser() для вызова методов класса APIClientUser()
  data_http = {"data_request": dict,
               "data_response": Response}
  data_http_request = {}
  data_http_response: Response = {}

  user_name_current: str = ""
  result_operation_user: bool = False

  """
    # Пробный вариант. Удалить по окончанию эксперимента! 
  def is_http_request_passed(self) -> bool:
      if "text" in self.data_http["data_response"]:
          tmp_dict = dict(self.data_http["data_response"].text)
      else:
          tmp_dict = self.data_http["data_response"]
      return ("200" in tmp_dict)    #("code" in tmp_dict) and
   """


  def exec_create_user(self, user_data: dict = {}, user_name: str = "", password: str = "", locale_lang = 'en_EN') -> bool:

      api_client_user = api_client.APIClientUser()
      self.result_operation_user = False
      print("\n\r")
      print(f'test_create_user():  Создание пользователя.')
      with (allure.step(f'test_create_user():  Создание пользователя.')):
          print('data_http["data_request = ',  self.data_http["data_request"])
          if len(user_data) == 0:  # Если на входе нет пользовательских данных, то создаём по вымышленным данным
              api_client_user.data_http["data_request"] = faker_data.FakerUserData(locale_lang).generate_user_test_data()
          else:  # Создание пользователя с реальными входными данными
              api_client_user.data_http["data_request"] = user_data

          api_client.APIClientUser.headers_auth_oa["name"] = user_name  # Заполнение данных аутентификации дл
          api_client.APIClientUser.headers_auth_oa["password"] = password  # передачи в функции классов api_client

          self.data_http = api_client.APIClientUser.api_post_user(self.api_client_user)  # Вызов без параметров - вымышленные данные для пользователя
#          print("user_name_created = ",  user_name_created)
#          print("Данные отправленные:",  self.data_http["data_request"])
#          print('Данные полученные:', self.data_http["data_response"].headers)
          try:
            assert self.data_http["data_response"].status_code == 200, print(f'{self.data_http["data_response"].headers}, {self.data_http["data_response"].content}')
            print("✅Тест пройден!")
         # Выборка имени пользователя и пароля из данных в запросе
            self.user_name_current = json.loads(self.data_http["data_request"]).get("user_Name")
            self.user_password_current = json.loads(self.data_http["data_request"]).get("password")
            self.result_operation_user = True
          except Exception: # AssertionError:
            print(Fore.RED + f'Тест не пройден! Ответ сервера: {self.data_http["data_response"]}')
            self.result_operation_user = False

      return self.result_operation_user


  def exec_get_user(self, user_name, password: str) -> bool:

      self.user_name_current = user_name
      self.user_password_current = password
      self.result_operation_user = False
      print(f'test_get_user():  Запрос данных пользователя "user_name" = {self.user_name_current}.')
      with allure.step(f'test_get_user():  Запрос данных пользователя "user_name" = {self.user_name_current}.'):
        self.data_http_request = api_client.APIClientUser.api_get_user(self.api_client_user, api_endpoint=api_client.APIEndpoints.api_user_get_login(self.user_name_current))
#        print("\n\r")
#        print("Данные полученные: ", self.data_http_request)
#        print("Данные отправленные:", self.data_http["data_request"])
#        if not self.is_http_request_passed():
        try:
            if self.data_http["data_response"].status_code == 200:
               print("✅Тест пройден!")
             # Выборка имени пользователя и пароля из данных в запросе
               self.user_name_current = json.loads(self.data_http["data_request"]).get("user_Name")
               self.user_password_current = json.loads(self.data_http["data_request"]).get("password")
               self.result_operation_user = True
            else:
                print(Fore.RED + f'Тест не пройден! Ответ сервера: {self.data_http["data_response"].text}')
                print(Fore.RED + f'{self.data_http["data_response"].headers}, {self.data_http["data_response"].content}')
        except Exception:  # AssertionError:
              print(Fore.RED + f'Тест не пройден! Ответ сервера: {self.data_http["data_response"].text}')
              self.result_operation_user = False

      return self.result_operation_user


  def exec_update_user(self, user_name: str, password: str = "") -> bool:

      self.result_operation_user = False
      print("\n\r")
      print(f'test_create_user():  Обновление данных пользователя "user_name" = {self.user_name_current}')
      with (allure.step(f'test_create_user():  Обновление данных пользователя "user_name" = {self.user_name_current}.')):
          self.data_http = api_client.APIClientUser.api_put_user(self.api_client_user)  # Вызов без параметров - вымышленные данные для пользователя
#          print('data_http["data_request = ',  self.data_http["data_request"])
#          print("user_name_created = ",  user_name_created)
#          print("Данные отправленные:",  self.data_http["data_request"])
#          print('Данные полученные .text["user_name"]:', self.data_http["data_response"].headers)
          try:
              assert self.data_http["data_response"].status_code == 200, print(
                  f'{self.data_http["data_response"].headers}, {self.data_http["data_response"].content}')
              print("✅Тест пройден!")
              # Выборка имени пользователя и пароля из данных в запросе
              self.user_name_current = json.loads(self.data_http["data_request"]).get("user_Name")
              self.user_password_current = json.loads(self.data_http["data_request"]).get("password")
              self.result_operation_user = True
              self.result_create_user = True
          except Exception:  # AssertionError:
              print(Fore.RED + f'Тест не пройден! Ответ сервера: {self.data_http["data_response"].text}')
              self.result_operation_user = False

      return self.result_operation_user


  def exec_login_user(self, user_name, password: str, user_data: dict = {}, locale_lang = 'en_EN') -> bool:

      api_client_user = api_client.APIClientUser()
      self.user_name_current = user_name
      self.user_password_current = password
      self.result_operation_user = False
      print(f'test_get_user():  Вход пользователя в учётную запись "user_name" = {self.user_name_current}.')
      with allure.step(f'test_get_user():  Вход пользователя в учётную запись "user_name" = {self.user_name_current}.'):
        api_client.APIClientUser.headers_auth_oa["name"] = user_name        # Заполнение данных аутентификации дл
        api_client.APIClientUser.headers_auth_oa["password"] = password     # передачи в функции классов api_client
        if len(user_data) == 0:  # Если на входе нет пользовательских данных, то создаём по вымышленным данным
            api_client_user.data_http["data_request"] = faker_data.FakerUserData(locale_lang).generate_user_data()
        else:  # Создание пользователя с реальными входными данными
            api_client_user.data_http["data_request"] = user_data
        #      headers_auth = api_client.OperationSchemaForCreating.headers_auth  # Получение данных уже в JSON
        #      headers_auth = ('test', 'abc123', 'special-key')
        #     print("headers_auth: ", headers_auth)

        self.data_http_request = api_client.APIClientUser.api_get_user(self.api_client_user, user_name = self.user_name_current)    #, user_data = {})
        print("\n\r")
        print("Данные полученные: ", self.data_http_request)
        print("Данные отправленные:", self.data_http["data_request"])
        try:
             assert self.data_http["data_response"].status_code == 200, print(f'{self.data_http["data_response"].headers}, {self.data_http["data_response"].content}')
             print("✅Тест пройден!")
             self.result_operation_user = True
        except Exception:  # AssertionError:
            print(Fore.RED + f'Тест не пройден! Ответ сервера: {self.data_http["data_response"].text}')
            self.result_operation_user = False

      return self.result_operation_user

  def exec_logout_user(self) -> bool:

      api_client_user = api_client.APIClientUser()
      # Очищаем все входные параметры
      self.user_name_current = ""
      self.user_password_current = ""
      self.result_operation_user = False
      print(f'test_get_user():  Выход пользователя из текущей сессии "user_name" = {self.user_name_current}.')
      with allure.step(f'test_get_user():  Выход пользователя из текущей сессии "user_name" = {self.user_name_current}.'):
          api_client.APIClientUser.headers_auth_oa["name"].clear()  # Заполнение данных аутентификации дл
          api_client.APIClientUser.headers_auth_oa["password"].clear()  # передачи в функции классов api_client
          api_client_user.data_http["data_request"].clear()

          self.data_http_request = api_client.APIClientUser.api_get_user(self.api_client_user)
          print("\n\r")
          print("Данные полученные: ", self.data_http_request)
          print("Данные отправленные:", self.data_http["data_request"])
          try:
              assert self.data_http["data_response"].status_code == 200, print(
                  f'{self.data_http["data_response"].headers}, {self.data_http["data_response"].content}')
              #       assert 'available' in data, "В ответе есть поле 'available'!"
              print("✅Тест пройден!")
              self.result_operation_user = True
          except Exception:  # AssertionError:
              print(Fore.RED + f'Тест не пройден! Ответ сервера: {self.data_http["data_response"].text}')
              self.result_operation_user = False

      return self.result_operation_user