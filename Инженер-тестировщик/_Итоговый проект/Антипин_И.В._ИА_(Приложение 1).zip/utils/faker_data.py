from faker import Faker
import json

from faker.contrib.pytest.plugin import faker

MIN_FAKE_ID = 1
MAX_FAKE_ID = 999

class FakerUserData():

  """
  Класс-обертка над Faker, предоставляет методы генерации фейковых данных для пользователя.
  """
  user_id = int
  user_Name = str
  first_Name = str
  last_Name = str
  email = str
  password = str
  phone = str
  user_Status = int

  user_data = [user_id, user_Name, first_Name, last_Name, email, password, phone, user_Status]   #Прототип JSON Schema
  locale = str = "en_EN"

  def __init__(self, locale):   #в locale будет задаваться раскладка для генерируемых данных: en_EN или ru_RU
    """
    Инициализирует объект FakerUser с экземпляром Faker.

    :param faker: Экземпляр FakerUser для генерации случайных данных.
    """
    self.locale = locale
    self.faker = Faker() #self.locale

  def generate_user_data(self):
    """
    Генерирование вымышленных данных для пользователя API
    """
    self.user_data = {
        "id": self.faker.random_int(MIN_FAKE_ID, MAX_FAKE_ID),
        "user_Name": self.faker.user_name(),
        "first_Name": self.faker.first_name(),
        "last_Name": self.faker.last_name(),
        "email": self.faker.email(),
        "password": self.faker.password(),
        "phone": self.faker.phone_number(),
        "user_Status": 1
    }
    self.user_data["user_name"] = self.user_data["user_Name"] + str(self.user_data["id"])
    return json.dumps(self.user_data)

  def generate_user_test_data(self):
    """
    Возвращает предопределённого пользователя "test" в базе данных пользователей Swagger
    """
    self.user_data = {
        "id": 2,
        "user_Name": "test",
        "first_Name": "test",
        "last_Name": "test",
        "email": "test",
        "password": "test",
        "phone": "test",
        "user_Status": 2
    }
    return json.dumps(self.user_data)

  def generate_user_user1_data(self):
    """
    Частный случай - всё случайное, кроме имени пользователя = user1 (предопределённый в swagger.io)
    Возвращает предопределённого пользователя "test" в базе данных пользователей Swagger
    """
    self.user_data = {
        "id": self.faker.random_int(MIN_FAKE_ID, MAX_FAKE_ID),
        "user_Name": "user1",
        "first_Name": self.faker.first_name(),
        "last_Name": self.faker.last_name(),
        "email": self.faker.email(),
        "password": self.faker.password(),
        "phone": self.faker.phone_number(),
        "user_Status": 1
    }
    return json.dumps(self.user_data)

