import json
import requests

import utils.faker_data as faker_data
from requests.auth import HTTPBasicAuth


API_BASE_URL = "https://petstore.swagger.io"
SSL_SERTIFICATE_CHECK = False
SWAGGER_TOKEN = 'special-key'

class APIEndpoints:

  api_user_post = f'{API_BASE_URL}/v2/user'  #Возвращает адрес ресурса API для POST - создание пользователя
  api_user_post_list = f'{API_BASE_URL}/user/createWithList'  #Возвращает адрес ресурса API для POST - создание списка пользователей

  def api_user_get(user_id: str):
    """ Возвращает адрес ресурса API для метода GET"""
    return f'{API_BASE_URL}/v2/user/{user_id}'

  def api_user_put(user_name):
    """ Возвращает адрес ресурса API для метода PUT"""
    return f'{API_BASE_URL}/user/{user_name}'

  def api_user_delete(user_name):
    """ Возвращает адрес ресурса API для метода DELETE"""
    return f'{API_BASE_URL}/user/{user_name}'

  def api_user_get_login(user_name):
    """ Возвращает адрес ресурса API для входа пользователя
        Пример: https://petstore.swagger.io/v2/user/login?username=test&password=test
    """
    return f'{API_BASE_URL}/user/{user_name}/login'

  def api_user_get_logout(user_name):
    """ Возвращает адрес ресурса API для выхода пользователя"""
    return f'{API_BASE_URL}/v2/user/logout'    # v2/user/logout



"""
class APISchemaForCreating: # Используется при создании нового пользователя

  headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  headers_auth = HTTPBasicAuth('test', 'abc123')  # Swagger: Right now we have one user in our system: test, with passoword: abc123
#  headers_auth = {'Authorization': f'Bearer {SWAGGER_TOKEN}'}
#  user_data = json.dumps([headers, headers_auth])  # Прототип JSON Schema

class APISchemaForUpdating(): # Используется при обновлении существующего пользователя


class APISchemaForResponse(): # Используется при получении данных в ответе от сервера
  """

class APIClientUser:

  data_http = {"data_request": {},
               "data_response": requests.Response}
  headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  headers_auth_oa = {"name" : "", "password" : ""}  # Swagger: Right now we have one user in our system: test, with passoword: abc123

  api_user_endpoint: str = ""


  def api_post_user(self):

    self.api_user_endpoint = APIEndpoints.api_user_post
#    print("api_user_post = ", self.api_user_post)
#      headers_auth = ('test', 'abc123', 'special-key') #для тестирования
    try:
      self.data_http["data_response"] = requests.post(self.api_user_endpoint, headers = self.headers, auth = (self.headers_auth_oa["name"], self.headers_auth_oa["password"]), data = self.data_http["data_request"], timeout = (1, 1))
    except (requests.ConnectionError,
            requests.Timeout,
            requests.RequestException) as error:
      self.data_http["data_response"] = f'Ошибка HTTP-запроса: {error}'
      print("Ошибка HTTP-запроса: ", error)
    else:  # Продолжение работы в штатном режиме
      pass
#      self.data_http["data_response"] = self.data_response.json()
 #        print("oauth_tokens:", data_response['oauthToken'])
#    print('Перед выходом из api_create_user() self.data_http["data_response"] = ', self.data_http["data_response"])

    return self.data_http

  def api_get_user(self, user_name:str = "", api_endpoint: str = ""):

    if len(api_endpoint) > 0:
        self.api_user_endpoint = api_endpoint
    else:
        self.api_user_endpoint = APIEndpoints.api_user_get(user_name)
#    print("api_user_get = ", self.api_user_get)
    params_data = {}
    try:
#      self.data_http["data_response"] = requests.get(self.api_user_get, headers = headers_data, params = params_data, timeout=(1, 1))
      self.data_http["data_response"] = requests.get(self.api_user_endpoint, headers = self.headers, auth = (self.headers_auth_oa["name"], self.headers_auth_oa["password"]), timeout=(3, 3))
    except (requests.ConnectionError,
            requests.Timeout,
            requests.RequestException) as error:
      self.data_http["data_response"] = f'Ошибка HTTP-запроса: {error}'
      print("Ошибка HTTP-запроса: ", error)

    else:  # Продолжение работы в штатном режиме
      pass
#      self.data_http["data_response"] = self.data_response.json()
    return self.data_http


  def api_put_user(self, user_data: dict = {}, locale_lang='en_EN'):
      self.api_user_endpoint = APIEndpoints.api_user_post
      #    print("api_user_post = ", self.api_user_post)
#      if len(user_data) == 0:  # Если на входе нет пользовательских данных, то создаём по вымышленным данным
#        self.data_http["data_request"] = faker_data.FakerUserData(locale_lang).generate_user_test_data()
#      else:  # Создание пользователя с реальными входными данными
#        self.data_http["data_request"] = user_data

      #      headers_auth = ('test', 'abc123', 'special-key') #для тестирования
      try:
        self.data_http["data_response"] = requests.put(self.api_user_endpoint, headers = self.headers, auth = (self.headers_auth_oa["name"], self.headers_auth_oa["password"]), data=self.data_http["data_request"], timeout=(1, 1))  # , auth = headers_auth)
      except (requests.ConnectionError,
              requests.Timeout,
              requests.RequestException) as error:
        self.data_http["data_response"] = f'Ошибка HTTP-запроса: {error}'
        print("Ошибка HTTP-запроса: ", error)
      else:  # Продолжение работы в штатном режиме
        pass
      #      self.data_http["data_response"] = self.data_response.json()
      #        print("oauth_tokens:", data_response['oauthToken'])
      #    print('Перед выходом из api_create_user() self.data_http["data_response"] = ', self.data_http["data_response"])

      return self.data_http




"""

  def api_http_user(self, user_data: dict = {}, locale_lang = 'en_EN'):
#    Общее ядро для вызова всех методов http
#    все параметры должны быть настроены в переменных класса
    if len(self.data_http["data_request"]) == 0: # Если на входе нет пользовательских данных, то создаём по вымышленным данным
      self.data_http["data_request"] = faker_data.FakerUserData(locale_lang).generate_user_test_data()
    else: # Создание пользователя с реальными входными данными
      self.data_http["data_request"] = user_data

#      headers_auth = ('test', 'abc123', 'special-key')
    try:
      self.data_http["data_response"] = requests.post(self.api_user_post, headers = headers_data, data = self.data_http["data_request"], timeout = (1, 1)) #, auth = headers_auth)
    except (requests.ConnectionError,
            requests.Timeout,
            requests.RequestException) as error:
      self.data_http["data_response"] = f'Ошибка HTTP-запроса: {error}'
      print("Ошибка HTTP-запроса: ", error)
    else:  # Продолжение работы в штатном режиме
      pass
#      self.data_http["data_response"] = self.data_response.json()
 #        print("oauth_tokens:", data_response['oauthToken'])
#    print('Перед выходом из api_create_user() self.data_http["data_response"] = ', self.data_http["data_response"])

    return self.data_http
    
"""